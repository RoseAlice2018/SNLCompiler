#SNLPY

##主要功能

SNLPY是用python实现的SNL编译器，包括词法分析、语法分析和语义分析。

##目的

重现编译器的实现的细节，达到交流学习目的。

##GUI

GUI使用了node-webkit，此处并无打包，请在命令行下使用`nw SNLPY`，或者拖动SNLPY文件夹到nw中。

##关于作者

 - lkk [www.lk-life.com](http://www.lk-life.com)
 - yyq
 - jxy
